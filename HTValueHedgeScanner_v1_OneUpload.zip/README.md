# HT Value & Hedge Scanner v1 — 上半场概率价值与保险组合筛选器

这是 Android WebView + Java 原生网络/相册桥接的 Android 项目。无需第三方 JS 库、无需 Kotlin 或额外 Maven 依赖。源码在 `app/src/main/assets/index.html` 与 `MainActivity.java`。

## 已实现

- 上半场赛前批量扫描：目标场数可输入，默认 20，最大 60。仅输出通过筛选的比赛，场次不足不补齐。
- 主单金额可输入（默认 10000），主单最低赔率可输入（默认 3.0）。
- 从 API-Football 的 Bet365（bookmaker ID 8）赔率接口读取**上半场准确比分**赔率；不会用全场正确比分冒充。
- 读取主客队最近 10 场中有真实半场比分的比赛，样本不足则 PASS。无真实赔率/配额不足则报错，绝不生成假的比赛。
- 用平滑泊松模型输出多个上半场比分的粗略概率，再对各个主单 + 保险单配对计算期望 ROI 与风险；不是经过证实的盈利模型。
- 自动保险：保护比例为 100% 时 `H=ceil(M/(O-1))`；保护 50% 时 `H=ceil(0.5*M/(O-1))`。保险金额上限可设定。
- 可填写 OpenAI API Key，AI 只基于送入的统计数据审核风险，不能擅自创造伤停或赔率，也不能修改数值概率。无 Key 时可使用数学筛选，并显著标注未进行AI审核。
- 导出安卓相册 PNG 图片、监控 JSON、复盘 CSV。图片字段包含比赛 ID、联赛、当地开赛时间、主客队、主单/保险比分、赔率、金额；大于 24 场自动分图。
- 显示全部保险成本及主单、保险、其他比分的净盈亏；非双重保险的数学幻象。

## GitHub 一键上传 ZIP 并编译

1. 新建或打开 GitHub 仓库。在 `.github/workflows/build-apk.yml` 粘贴与本项目同目录单独提供的 `build-apk.yml`，提交。
2. 上传 `HTValueHedgeScanner_v1_OneUpload.zip` 到仓库**根目录**，不需要解压，提交。
3. Actions -> `Build HT Value Hedge Scanner APK` -> 等待 build 成功。
4. 在 Actions 的 Artifacts 中下载 `HTValueHedgeScanner-debug-apk`，解压后安装 `app-debug.apk`。

也可以将 ZIP 解压后的源码放到仓库根目录，工作流能自动识别。

## 数据接口说明

- 足球 API：`GET https://v3.football.api-sports.io/odds?date=YYYY-MM-DD&bookmaker=8&page=N`
- 赛事元信息：`GET /fixtures?date=...&timezone=America/Argentina/Buenos_Aires`
- 球队半场历史：`GET /fixtures?team=TEAMID&last=10`
- AI：OpenAI `POST /v1/chat/completions` （默认 gpt-4o-mini，JSON 输出）

由于 API-Football 赛前盘口并非每场都有半场正确比分，并受套餐、保留期、每3小时更新频率影响，每日可选场数不保证达到目标场数。使用前请核对 Bet365 App 上的实时赔率。

## 与旧预警 App 的兼容性

本版建立了 `HT_MONITOR_EXPORT_V1` JSON 交换格式和一致的高对比度 PNG OCR 识别字段。**没有现有预警App的源代码与原始图片解析规则，不能证明“直接识别即兼容”**。建议先导出1张图，在预警App尝试导入；如仍不识别，请用预警App源ZIP进一步对齐模板或直接导入JSON。不能以未验证的兼容性替代实际测试。

## 重要限制

- 这是**研究和模拟验证原型**。近期半场简单泊松模型与收益估计未经样本外校准；正模型 ROI ≠ 已证明的正期望。
- 现在尚未实现自动交易、提前结算、推送或下注账户连接。
- 足球API与OpenAI Key仅存在于输入框和网络请求内存，不写入本地数据库。直接在客户端使用API Key并不能防止被恶意/Root设备捕获；生产部署应使用授权后端代理，并设置配额。
- 没有使用真实API Key执行网络集成测试，也没有在本环境完成 Gradle Android 编译。JS语法和保险计算已进行本地静态/单元测试；最终APK须通过GitHub Actions构建验证。
