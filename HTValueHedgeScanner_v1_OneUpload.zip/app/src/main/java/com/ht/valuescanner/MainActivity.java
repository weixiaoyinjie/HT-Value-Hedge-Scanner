package com.ht.valuescanner;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
  private WebView browser;
  private final ExecutorService executor = Executors.newFixedThreadPool(3);

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(8,22,34));
    getWindow().setNavigationBarColor(Color.rgb(8,22,34));
    browser = new WebView(this);
    WebSettings settings = browser.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(false); // API keys must not persist in localStorage.
    settings.setAllowContentAccess(false);
    settings.setAllowFileAccess(true); // Only loads bundled asset document.
    settings.setAllowFileAccessFromFileURLs(false);
    settings.setAllowUniversalAccessFromFileURLs(false);
    browser.setWebChromeClient(new WebChromeClient());
    browser.setWebViewClient(new WebViewClient());
    browser.addJavascriptInterface(new JsBridge(), "AndroidBridge");
    browser.loadUrl("file:///android_asset/index.html");
    setContentView(browser);
  }

  private boolean allowed(String method, URL url) {
    if (!"https".equalsIgnoreCase(url.getProtocol())) return false;
    if ("v3.football.api-sports.io".equalsIgnoreCase(url.getHost())) {
      return "GET".equals(method) && (url.getPath().equals("/odds") || url.getPath().equals("/fixtures") || url.getPath().equals("/odds/bets"));
    }
    return "api.openai.com".equalsIgnoreCase(url.getHost()) && "POST".equals(method) && "/v1/chat/completions".equals(url.getPath());
  }

  private JSONObject fetch(String method, String url, String headerJson, String body) {
    HttpURLConnection conn = null;
    JSONObject answer = new JSONObject();
    try {
      URL target = new URL(url);
      if (!allowed(method, target)) throw new IllegalArgumentException("拒绝未经授权的网络地址或方法");
      conn = (HttpURLConnection) target.openConnection();
      conn.setConnectTimeout(15000); conn.setReadTimeout(30000);
      conn.setInstanceFollowRedirects(false); // Prevent redirects to other hosts.
      conn.setRequestMethod(method);
      conn.setRequestProperty("Accept", "application/json");
      JSONObject headers = new JSONObject(headerJson);
      if (target.getHost().equals("api.openai.com")) {
        conn.setRequestProperty("Authorization", headers.optString("Authorization"));
        conn.setRequestProperty("Content-Type", "application/json");
      } else {
        conn.setRequestProperty("x-apisports-key", headers.optString("x-apisports-key"));
      }
      if ("POST".equals(method)) {
        conn.setDoOutput(true);
        try (OutputStream out = conn.getOutputStream()) { out.write(body.getBytes(StandardCharsets.UTF_8)); }
      }
      int code = conn.getResponseCode();
      InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
      ByteArrayOutputStream bytes = new ByteArrayOutputStream();
      if (stream != null) try (InputStream in = stream) {
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) != -1) {
          bytes.write(buf, 0, n);
          if (bytes.size() > 4_000_000) throw new IllegalStateException("API响应过大");
        }
      }
      answer.put("ok", code >= 200 && code < 300);
      answer.put("status", code);
      answer.put("data", new String(bytes.toByteArray(), StandardCharsets.UTF_8));
    } catch(Exception e) {
      try { answer.put("ok", false); answer.put("status", 0); answer.put("error", e.getMessage()); } catch(Exception ignore) {}
    } finally { if (conn != null) conn.disconnect(); }
    return answer;
  }

  final class JsBridge {
    @JavascriptInterface public void request(final String id, final String method, final String url, final String headers, final String body) {
      executor.execute(() -> {
        JSONObject result = fetch(method, url, headers, body);
        runOnUiThread(() -> {
          if (browser == null) return;
          browser.evaluateJavascript("window.__nativeResult(" + JSONObject.quote(id) + "," + result.toString() + ")", null);
        });
      });
    }

    @JavascriptInterface public void saveImage(final String dataUrl, final String fileName) {
      executor.execute(() -> {
        try {
          String raw = dataUrl.substring(dataUrl.indexOf(',') + 1);
          byte[] bytes = android.util.Base64.decode(raw, android.util.Base64.DEFAULT);
          String name = safeName(fileName, ".png");
          if (Build.VERSION.SDK_INT >= 29) {
            ContentValues meta = new ContentValues();
            meta.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            meta.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            meta.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/HTValueScanner");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, meta);
            if (uri == null) throw new Exception("无法建立图片文件");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) { os.write(bytes); }
            notifyUser("图片已保存至相册 / Pictures/HTValueScanner");
          } else {
            // Android 8-9: share the PNG through system document picker, no broad storage permission.
            pendingSave = bytes; pendingName = name;
            runOnUiThread(() -> {
              Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
              i.setType("image/png"); i.addCategory(Intent.CATEGORY_OPENABLE);
              i.putExtra(Intent.EXTRA_TITLE, name);
              startActivityForResult(i, 601);
            });
          }
        } catch (Exception e) { notifyUser("保存图片失败：" + e.getMessage()); }
      });
    }

    @JavascriptInterface public void saveText(String content, String name, String mime) {
      pendingSave = content.getBytes(StandardCharsets.UTF_8); pendingName = safeName(name, ".json");
      pendingMime = "text/csv".equals(mime) ? "text/csv" : "application/json";
      runOnUiThread(() -> {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.setType(pendingMime); intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_TITLE, pendingName);
        startActivityForResult(intent, 602);
      });
    }
  }

  private volatile byte[] pendingSave; private volatile String pendingName; private volatile String pendingMime;
  private static String safeName(String name, String extension) {
    String clean = name == null ? "HTScanner" : name.replaceAll("[^a-zA-Z0-9._-]", "_");
    if (!clean.toLowerCase().endsWith(extension)) clean += extension;
    return clean;
  }
  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if ((requestCode == 601 || requestCode == 602) && resultCode == RESULT_OK && data != null) {
      try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
        if (pendingSave != null && out != null) { out.write(pendingSave); notifyUser("文件已保存"); }
      } catch (Exception e) { notifyUser("文件保存失败：" + e.getMessage()); }
      pendingSave = null;
    }
  }
  private void notifyUser(String msg) { runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show()); }
  @Override protected void onDestroy() {
    executor.shutdownNow(); if (browser != null) browser.destroy(); browser=null; super.onDestroy();
  }
}
