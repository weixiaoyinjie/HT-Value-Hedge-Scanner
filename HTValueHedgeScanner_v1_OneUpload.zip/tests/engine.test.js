const fs=require('fs'),vm=require('vm'),assert=require('assert');
const script=fs.readFileSync('app/src/main/assets/index.html','utf8').split('<script>')[1].split('</script>')[0];
const fields={};
const env={window:{},document:{getElementById(id){return fields[id]??(fields[id]={value:'',textContent:'',style:{},disabled:false,innerHTML:''});}},Intl,Date,Math,Map,Set,Number,JSON,Promise,String,Error,console,setTimeout,clearTimeout};
vm.createContext(env);vm.runInContext(script,env);
const a=vm.runInContext(`(()=>{
 const raw=[{fixture:{id:100},bookmakers:[{id:8,name:'Bet365',bets:[{name:'Correct Score',values:[{value:'1-0',odd:'9.0'}]},{name:'Half Time Correct Score',values:[{value:'1:0',odd:'4.8'},{value:'0:0',odd:'2.0'},{value:'0:1',odd:'5.3'}]}]}]}];
 const odds=getOdds(raw);const obj={odds:odds.get(100).odds,model:{probs:{'1-0':.31,'0-0':.40,'0-1':.17}}};
 const p=calculate(obj,'1-0','0-0',10000,1,2,3,0);return {odds:obj.odds,ins:p.insurance,profitHedge:p.profitHedge,profitMain:p.profitMain,cost:p.cost};})()`,env);
assert.equal(a.odds['1-0'],4.8,'Use half-time odds, not full-time');
assert.equal(a.ins,10000,'100% protection at 2.0');
assert.equal(a.profitHedge,0,'Insurance win is break-even');
assert.equal(a.profitMain,28000,'Profit main returns minus both stakes');
console.log('PASS: first-half odds validation and main/insurance accounting.');
